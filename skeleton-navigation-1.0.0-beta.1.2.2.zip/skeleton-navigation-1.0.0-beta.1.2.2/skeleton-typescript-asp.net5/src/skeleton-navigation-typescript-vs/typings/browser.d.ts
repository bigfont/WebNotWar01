/// <reference path="browser\ambient\angular-protractor\angular-protractor.d.ts" />
/// <reference path="browser\ambient\es6-promise\es6-promise.d.ts" />
/// <reference path="browser\ambient\jasmine\jasmine.d.ts" />
/// <reference path="browser\ambient\selenium-webdriver\selenium-webdriver.d.ts" />
