/// <reference path="main\ambient\angular-protractor\angular-protractor.d.ts" />
/// <reference path="main\ambient\es6-promise\es6-promise.d.ts" />
/// <reference path="main\ambient\jasmine\jasmine.d.ts" />
/// <reference path="main\ambient\selenium-webdriver\selenium-webdriver.d.ts" />
