/// <reference path="browser/ambient/es6-collections/index.d.ts" />
/// <reference path="browser/ambient/es6-promise/index.d.ts" />
