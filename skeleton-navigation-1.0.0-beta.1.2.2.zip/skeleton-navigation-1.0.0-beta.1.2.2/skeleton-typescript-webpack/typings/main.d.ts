/// <reference path="main/ambient/es6-collections/index.d.ts" />
/// <reference path="main/ambient/es6-promise/index.d.ts" />
